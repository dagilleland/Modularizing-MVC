﻿/* Scripts for your project */
if (console.log) {
    console.log('Heartbeat for Component page');
}
