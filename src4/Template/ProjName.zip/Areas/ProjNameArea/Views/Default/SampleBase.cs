﻿using $safeprojectname$.Areas.$safeprojectname$Area.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace $safeprojectname$.Areas.$safeprojectname$Area.Views.Default
{
    public abstract class SampleBase : WebViewPage<DemoModule>
    {
        
    }
}